#include "doubly.h"

using namespace std;

DoublyLinkedList::DoublyLinkedList(){
    head = nullptr;
    numElements = 0;
}

void DoublyLinkedList::push(int data){
    
    numElements++;
    
    if(head == nullptr){
        head = new node;
        head->data = data;
        return;
    }
    
    node* temp = head;
    while(temp->next != nullptr){
        temp = temp->next;
    }
    temp->next = new node;
    temp->next->data = data;
    temp->next->prev = temp;
    
}

void DoublyLinkedList::pop(){
    if(head->next == nullptr){
        delete head;
        head = nullptr;
        numElements--;
        return;
    }
    
    node* currentNode = head;
    while(currentNode->next->next != nullptr){
        currentNode = currentNode->next;
    }
    delete currentNode->next;
    currentNode->next = nullptr;
    numElements--;
}

int DoublyLinkedList::size() const{
    return numElements;
}

int& DoublyLinkedList::at(int index) const{
    int currentIndex = 0;
    node* currentNode = head;
    
    while(true){
        if(currentIndex == index){
            return currentNode->data;
        }
        
        currentIndex++;
        currentNode = currentNode->next;
    }
}

void DoublyLinkedList::print() const{
    for(int i = 0; i < size(); i++){
        cout << at(i) << endl;
    }
}

void DoublyLinkedList::insert(int data, int pos){
   
    int currentIndex = 0;
    
    node* currentNode = head;
    
    node* new_node = new node();

    
    while(true){
        if(currentIndex == pos)
            break;
        currentIndex++;
        currentNode = currentNode->next;
    }
    
    new_node->data = data;
    if(currentIndex == 0){
        head->prev = new_node;
        new_node->next = head;
        head = new_node;
    }
    else if(currentIndex == numElements){
        push(data);
        return;
    }
    else{
    
        new_node->prev = currentNode->prev;
        currentNode->prev->next = new_node;
        currentNode->prev = new_node;
        new_node->next = currentNode;
    }
    
   numElements++;
}

void DoublyLinkedList::remove(int pos){
    
    int currentIndex = 0;
    
    node* currentNode = head;
    
    if(pos == 0){
        node* temp = head;
        if(head->next == nullptr){
            head = nullptr;
        } 
        else {
            head = head->next;
        }
        delete temp;
        numElements--;
        return;
    }
    else{
        while(true){
        if(currentIndex == pos - 1)
            break;
        currentIndex++;
        currentNode = currentNode->next;
        }
        if(currentIndex == 0){
            delete currentNode->prev;
        }
        else{
    node* tempNode = currentNode->next->next;
    delete currentNode->next;
    currentNode->next = tempNode;
    tempNode->prev = currentNode;
    numElements--;
        }
    }
}  
    DoublyLinkedList::~DoublyLinkedList(){
    std::cout << "Destructor Called!" << std::endl;
    while(numElements > 0)
        pop();
    }
    
    DoublyLinkedList::DoublyLinkedList(const DoublyLinkedList& objToCopy){
    std::cout << "Copy Constructor Called!" << std::endl;
    
    head = nullptr;
    numElements = 0;
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
    }
    
    DoublyLinkedList& DoublyLinkedList::operator=(const DoublyLinkedList& objToCopy) {
    std::cout << "Copy Assignment Override Called!" << std::endl;
    
    while(numElements > 0)
        pop();
        
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
    }
    
