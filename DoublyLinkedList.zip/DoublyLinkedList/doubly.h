#ifndef DOUBLY_H
#define DOUBLY_H

#include <iostream>

struct node{
    int data;
    node* next = nullptr;
    node* prev = nullptr;
};

class DoublyLinkedList{
    
    public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    DoublyLinkedList(const DoublyLinkedList& objToCopy);
    DoublyLinkedList& operator=(const DoublyLinkedList& objToCopy);
    void push(int data);
    void pop();
    int size() const;
    void print() const;
    int& at(int index) const;
    void insert(int data, int pos);
    void remove(int pos);
    
    private:
    node* head;
    int numElements;
    
    
};

#endif