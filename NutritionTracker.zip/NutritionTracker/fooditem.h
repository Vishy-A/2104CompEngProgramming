#ifndef FOODITEM_H
#define FOODITEM_H

#include <string>
#include <vector>

using namespace std;

class FoodItem {
    public:
    void setFood(string n = "Name", double cal = 0, double fat = 0, double sug = 0, double pro = 0, double sod = 0);
    FoodItem operator+(FoodItem rhs);
    void Print() const;
    string getName() const;
    double getCal() const;
    double getFat() const;
    double getSug() const;
    double getPro() const;  
    double getSod() const;
    string foodDetails() const;
    
    
    private:
    string name;
    double calories;
    double totalFat;
    double sugars;
    double protein;
    double sodium;
};

#endif