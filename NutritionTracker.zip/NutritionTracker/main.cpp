#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include "fooditem.h"
#include "FoodItem.cpp"

using namespace std;

int main() {
    
    cout << "Hello, this program is designed to display the total nutritional values of various food items, and how much of one's daily intake they consist of." << endl;
    
    vector<FoodItem> foods;
    
    vector<FoodItem> chosenFoods;
    
    FoodItem f1;
    f1.setFood("Spicy Instant Ramen", 520, 14, 8, 13, 1.71);
    
    foods.push_back(f1);
    
    FoodItem f2;
    f2.setFood("Butter Popcorn", 140, 7, 0, 2, .31);
    
    foods.push_back(f2);
    
    FoodItem f3;
    f3.setFood("Shrimp Fried Rice", 360, 10, 4, 12, .99);
    
    foods.push_back(f3);
    
    FoodItem f4;
    f4.setFood("Protein Bar", 200, 7, 2, 20, .2);
    
    foods.push_back(f4);
    
    FoodItem f5;
    f5.setFood("Apple", 130, 0, 25, 1, 0);
    
    foods.push_back(f5);
    
    FoodItem f6;
    f6.setFood("Chocolate Chip Cookie", 200, 10, 13, 2, .125);
    
    foods.push_back(f6);
    
    FoodItem f7;
    f7.setFood("Protein Pancake Bowl", 190, 2, 3, 14, .395);
    
    foods.push_back(f7);
    
    FoodItem f8;
    f8.setFood("Grilled Chicken Sandwich", 380, 11, 11, 28, .755);

    foods.push_back(f8);
    
    FoodItem f9;
    f9.setFood("Watermelon Slice", 40, 0, 10, 1, .002);
    
    foods.push_back(f9);
    
    FoodItem f10;
    f10.setFood("Can of Miller Lite", 96, 0, 0, 1, .005);
    
    foods.push_back(f10);
    
    FoodItem total;
    f10.setFood("Total", 0, 0, 0, 0, 0);
    
    

    
    bool runProgram = true;
    
    while(runProgram == true){
    int listSize;    
    for(int i = 0; i < foods.size(); i++){
        cout << i + 1 << ". " << foods.at(i).getName() <<endl;
        listSize = i;
    }
    cout << listSize + 2 << ". Input your own food." << endl;
    listSize++;
    cout << listSize + 2 << ". Quit the program and calculate." << endl;
    listSize++;
    
    cout << "Please input the itemized number of the food you would like to add, if you want to input your own food, or if you want to quit the program and calculate your total nutritional intake." << endl;
    string userInput;
    int intUserInput;
    cin >> userInput; 
    intUserInput = atoi(userInput.c_str());
    
    if(intUserInput > listSize + 1 || intUserInput < 1){
        cout << "Invalid input! Please enter a numerical value listed." << endl;
        
    }
    
    else if (intUserInput > 0 && intUserInput < listSize)   {
        cout << "You've selected " << foods.at(intUserInput - 1).getName() << endl;
        chosenFoods.push_back(foods.at(intUserInput - 1));
        total = total + foods.at(intUserInput - 1);

    }
    
    else if (intUserInput == listSize){
        bool userInputting = true;
        string userName;
        string userCal; int intUserCal;
        string userFat; int intUserFat;
        string userSug; int intUserSug;
        string userPro; int intUserPro;
        string userSod; int intUserSod;
        while(userInputting == true){
                
            cout << "Please input the name of the food." << endl; cin >> userName;
            cout << "Please enter the number of calories" << endl; cin >> userCal;
            cout << "Please enter the grams of fat." << endl; cin >> userFat;
            cout << "Please enter the grams of sugar." << endl; cin >> userSug;
            cout << "Please enter the grams of protein." << endl; cin >> userPro;
            cout << "Please enter the grams of sodium." << endl; cin >> userSod;
 
            intUserCal = atoi(userCal.c_str());
            intUserFat = atoi(userFat.c_str());
            intUserSug = atoi(userSug.c_str());
            intUserPro = atoi(userPro.c_str());
            intUserSod = atoi(userSod.c_str());
    
            if(intUserCal < 0 || intUserFat < 0 || intUserSug < 0 || intUserPro < 0 || intUserSod < 0){
                cout << "Invalid input! Please enter numerical values for calories and grams." << endl;
        
            }
            
            else{
                FoodItem userMade;
                userMade.setFood(userName, intUserCal, intUserFat, intUserSug, intUserPro, intUserSod);
                foods.push_back(userMade);
                chosenFoods.push_back(userMade);
            userInputting = false;
                
            }
            
            
        }
        listSize++;
    }
    
    else if (intUserInput == listSize + 1){
        runProgram = false;
    }
    
    }
    

    
    for(int i = 0; i < chosenFoods.size(); i++){
        cout << chosenFoods.at(i).getName() <<endl;
        
    }
    if(chosenFoods.size() == 0){
        cout << "No foods were selected." << endl;
    }
    else{
    total.Print();
    }
    cout << "The program has been closed. Thank you for using!" << endl;
    return 0;
    
}