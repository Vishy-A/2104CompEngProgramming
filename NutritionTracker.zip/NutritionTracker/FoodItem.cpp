#include "fooditem.h"

void FoodItem::setFood(string n, double cal, double fat, double sug, double pro, double sod){
    name = n;
    calories = cal;
    totalFat = fat;
    sugars = sug;
    protein = pro;
    sodium = sod;
}
    
FoodItem FoodItem::operator+(FoodItem rhs){
    
    FoodItem healthTotal;
    healthTotal.name = "Total";
    healthTotal.calories = calories + rhs.calories;
    healthTotal.totalFat = totalFat + rhs.totalFat;
    healthTotal.sugars = sugars + rhs.sugars;
    healthTotal.protein = protein + rhs.protein;
    healthTotal.sodium = sodium + rhs.sodium;
    
    return healthTotal;
}

void FoodItem::Print() const{
    cout << name << endl;
    cout << "Calories: " << calories << endl << "Total Fat (g): " << totalFat << endl << "Total Sugars (g):  " << sugars << endl;
    cout << "Total Protein (g): " << protein << endl << "Total Sodium (g): " << sodium << endl;
    if(calories > 2000){
        cout << "You have exceeded the recommended daily caloric intake by " << calories - 2000 << endl;
    }
    if(totalFat > 70){
        cout << "You have exceeeded the recommended daily fat intake by " << totalFat - 70 << " grams." << endl;
    }
    if(sugars > 30){
        cout << "You have exceeded the recommended daily sugar intake by " << sugars - 30 << " grams." << endl;
    }
    if(protein > 50){
        cout << "You have exceeded the recommended daily protein intake by " << protein - 50 << " grams." << endl;
    }
    if(sodium > 2.3){
        cout << "You have exceeded the recommended daily sodium intake by " << sodium - 2.3 << " grams." << endl;
    }
}

string FoodItem::getName() const {
    return name;
}

double FoodItem::getCal() const {
    return calories;
}

double FoodItem::getFat() const {
    return totalFat;
}

double FoodItem::getSug() const {
    return sugars;
}

double FoodItem::getPro() const {
    return protein;
}

double FoodItem::getSod() const {
    return sodium;
}

