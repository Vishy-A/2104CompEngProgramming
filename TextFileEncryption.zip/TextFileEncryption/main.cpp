// C++ program for the above approach
 
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
 
class crypt {
    
 
    string file = "HelloWorld.txt";
    char c;
 
public:
    void encrypt();
    void decrypt();
    string outputFile;
    int key;
    
};


void crypt::encrypt()
{

 
    fstream fin, fout;
 

    fin.open(file, fstream::in);
    fout.open("encrypt.txt", fstream::out);
 
    while (fin >> noskipws >> c) {
        int temp = (c + key);
 

        fout << (char)temp;
    }
 
    fin.close();
    fout.close();
}


void crypt::decrypt()
{
    
    fstream fin;
    fstream fout;
    
    fin.open("encrypt.txt", fstream::in);
    fout.open("decrypt.txt", fstream::out);
 
    while (fin >> noskipws >> c) {
 

        int temp = (c - key);
        fout << (char)temp;
    }
 
    fin.close();
    fout.close();
}

int main(){
    crypt cry;
    int key;
    
    if(argc != 8){
        cout << "Incorrect amount of arguments" << endl;
        return 1;
    }
    
    string outputFile;
    string fileName;
    
    for(int i = 0; i < argc; i++){
        if(strcmp(argv[i], "-i") == 0)
            fileName = argv[i + 1];
        if(strcmp(argv[i], "-k") == 0){
            key = atoi(argv[i + 1]);
            if(key == 0){
                cout << "Please ensure the key is an integer that is not equal to zero." << endl;
                return 1;
            }
        }
        
        if(strcmp(argv[i], "-o") == 0)
            outputFile = argv[i + 1];
        
        
        if(strcmp(argv[i], "-e") == 0)
            cry.encrypt();
        
        
        if(strcmp(argv[i], "-d") == 0)
            cry.decrypt();
        
        
    }
    
}
    
