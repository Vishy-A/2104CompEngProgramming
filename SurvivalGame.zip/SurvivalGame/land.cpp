
#include "land.h"
Land* getRandomLand(){
    LandTypes selection = (LandTypes)(rand() % NUM_LANDS);
    
    switch(selection){
        case FOREST:
            return new Forest;
        break;
        case LAKE:
            return new Lake;
        break;
        case RIVER:
            return new River;
        break;
        case DESERT:
            return new Desert;
        break;
        case TOWN:
            return new Town;
        break;
        case CAVE:
            return new Cave;
        break;
        case FIELD:
            return new Field;
        break;
        case MOUNTAIN:
            return new Mountain;
        break;
        case STRANGER:
            return new Stranger;
        break;
        case STRANGER2:
            return new Stranger2;
        break;
        case STRANGER3:
            return new Stranger3;
        break;
        default:
            return nullptr;
        break;
    }
}
string Forest::getDescription(){
    return "a densely wooded forest.";
}
string Forest::visit(Player& player){
    player.setHunger(player.getHunger() + 1);
    return "You venture into the forest and forage for nuts and berries, restoring your hunger";
}
string Lake::getDescription(){
    return "a sparkling clear lake.";
}
string Lake::visit(Player& player){
    player.setThirst(player.getThirst() + 1);
    return "You drink from the lake, re-hydrating yourself.";
}
string River::getDescription(){
    return "a flowing river.";
}
string River::visit(Player& player){
    player.setHunger(player.getHunger() + 1);
    player.setThirst(player.getThirst() + 1);
    return "You catch a fish and get clean water from the river, restoring your hunger and re-hydrating yourself.";
}
string Desert::getDescription(){
    return "an arid desert.";
}
string Desert::visit(Player& player){
    return "You don't find anything of value in the desert.";
}
string Town::getDescription(){
    return "a quiet town.";
}
string Town::visit(Player& player){
    player.setHealth(player.getHealth() + 1);
    return "You meet some townspeople who treat your injuries and aid you, restoring your health.";
}
string Cave::getDescription(){
    return "a dark cave.";
}
string Cave::visit(Player& player){
    player.setHealth(player.getHealth() - 1);
    return "The cave was a wolf den! You manage to escape with some injuries.";
}
string Field::getDescription(){
    return "a sprawling field.";
}
string Field::visit(Player& player){
    player.setHunger(player.getHunger() + 2);
    return "You manage to hunt a rabbit, greatly restoring your hunger.";
}
string Mountain::getDescription(){
    return "a snowcapped moutnain.";
}
string Mountain::visit(Player& player){
    player.setThirst(player.getThirst() + 2);
    return "You climb to one of the peaks and use the abundance of snow for clean water.";
}
string Stranger::getDescription(){
    return "a lonely stranger in the distance.";
}
string Stranger::visit(Player& player){
    player.setHealth(player.getHealth() - 10);
    return "The stranger turns to you with a strange look in their eyes. They slowly place their hands around your throat, your fingers scratching uselessly against them. The color starts to seep out of the world and the sounds begin to dull.";
}
string Stranger2::getDescription(){
    return "a lonely stranger in the distance.";
}
string Stranger2::visit(Player& player){
    player.setHunger(player.getHunger() + 1);
    player.setThirst(player.getThirst() + 1);
    return "The stranger turns to you with a smile. They introduce themselves and give you some provisions, as a token of kindness from one wanderer to another.";
}
string Stranger3::getDescription(){
    return "a lonely stranger in the distance.";
}
string Stranger3::visit(Player& player){
    return "You attempt to approach the stranger. You blink as a sudden gust reaches you, and the stranger is no longer there. A mirage, a ghost, or something else?";
}