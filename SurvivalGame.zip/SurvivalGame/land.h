
#ifndef LAND_H
#define LAND_H
#include <string>
#include "player.h"
using namespace std;
enum LandTypes {FOREST, LAKE, RIVER, DESERT, TOWN, CAVE, FIELD, MOUNTAIN, STRANGER, STRANGER2, STRANGER3, NUM_LANDS};
class Land {
    public:
    virtual string getDescription(){
        return "Description of land";
    }
    
    virtual string visit(Player& player){
        return "You visit a land";
    }
};
class Forest : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Lake : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class River : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Town : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Desert : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Cave : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Field : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Mountain : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Stranger : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Stranger2 : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
class Stranger3 : public Land {
    public:
    string getDescription();
    
    string visit(Player& player);
};
Land* getRandomLand();
#endif

