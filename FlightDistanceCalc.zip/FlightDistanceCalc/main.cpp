#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <cmath>

using namespace std;

const double earthRadius = 3958.8;

double haversine(double lat1, double long1, double lat2, double long2, double radius){
    double distance;
    double distLat = (lat2 * (M_PI/180) - (lat1 * (M_PI/180))) / 2;
    double distLong = (long2 * (M_PI/180) - (long1 * (M_PI/180))) / 2;
    
    double firstAdd = pow(sin(distLat), 2);
    double secondAdd = cos(lat1) * cos(lat2) * pow(sin(distLong), 2);
    
    double afterArcSin = asin(sqrt(firstAdd + secondAdd));
    distance = 2 * radius * (afterArcSin);
    
    return distance;
    
}

double getFlightTime(double lat1, double long1, double lat2, double long2){
    double distBetween = haversine(lat1, long1, lat2, long2, earthRadius);
    return distBetween / 517.5;
}
    

int main(){

    cout << "Hello there! This program computes the amount of time it takes for an airplane to fly from one GPS location to another." << endl;
    
    cout << "Below is a list of 10 different cities, please choose the departure location by entering it's number on the list." << endl;
    
    vector<string> locationNames{"Eureka, CA, USA", "Richmond, VA, USA", "Cary, NC, USA", "New York City, NY, USA", "Boston, MA, USA", "Las Vegas, NV, USA",
    "Chicago, IL, USA", "Charlotte, NC, USA", "Houston, TX, USA", "Miami, FL, USA", "Detroit, MI, USA", "San Francisco, CA, USA"}; 
    
    vector<double> locationLat{40.8021, 37.5407, 35.7915, 40.7128, 42.3601, 36.1699, 41.8781, 35.2271, 29.7604, 25.7617, 42.3314, 37.7749};
        
    vector<double> locationLong{124.1637, 77.4360, 78.7811, 74.006, 71.0589, 115.1398, 87.6298, 80.8431, 95.3698, 80.1918, 83.0458, 122.4194};
    
    for(int i = 0; i < 10; i++){
        cout << i + 1 << ". " << locationNames[i] << "  " << locationLat[i] << ", " << locationLong[i] << endl;
        
    }
    
    string departureNum;
    string arrivalNum;
    string location1Name;
    double location1Lat;
    double location1Long;
    string location2Name;
    double location2Lat;
    double location2Long;
    
    bool withinList = false;
    
    int intDepartureNum;
    
    while(withinList == false){
        
        cin >> departureNum;
        
        intDepartureNum = atoi(departureNum.c_str());
            
        if(intDepartureNum == 0){
            cout << "Invalid input! Please enter a numerical value." << endl;
            
        }
        
        if((intDepartureNum > 0 && intDepartureNum < 11)){
            
            cout << "You've selected "<<  locationNames[intDepartureNum - 1] << " at " << locationLat[intDepartureNum - 1] << ", " << locationLong[intDepartureNum - 1] << " for your departure location." << endl;
            
            withinList = true;
        } else {
        
            cout << "Please select a number between 1 and 10 as listed." << endl;
            intDepartureNum = 0;
        }

        
    }
    
    location1Name = locationNames[intDepartureNum - 1];
    location1Lat = locationLat[intDepartureNum - 1];
    location1Long = locationLong[intDepartureNum - 1];
    
    intDepartureNum = atoi(departureNum.c_str());
    
    locationNames.at(intDepartureNum - 1) = locationNames.at(10);
    locationLat.at(intDepartureNum - 1) = locationLat.at(10);
    locationLong.at(intDepartureNum - 1) = locationLong.at(10);
    
    cout << "Thank you, now please select the arrival destination from the list presented below by inputting the corresponding number." << endl;
    
    for(int i = 0; i < 10; i++){
        cout << i + 1 << ". " << locationNames[i] << "  " << locationLat[i] << ", " << locationLong[i] << endl;
        
    }
    
    withinList = false;
    
    int intArrivalNum;
    
    while(withinList == false){
        
        cin >> arrivalNum;
        
        intArrivalNum = atoi(arrivalNum.c_str());
        
        if(intArrivalNum == 0){
            cout << "Invalid input! Please enter a numerical value." << endl;
            
        }
        
        if((intArrivalNum > 0 && intArrivalNum < 11)){
            
            cout << "You've selected "<<  locationNames[intArrivalNum - 1] << " at " << locationLat[intArrivalNum - 1] << ", " << locationLong[intArrivalNum - 1] << " for your arrival location." << endl;
            
            withinList = true;
        } else {
        
            cout << "Please select a number between 1 and 10 as listed." << endl;
            intArrivalNum = 0;
        }
        

    }
    
    location2Name = locationNames[intArrivalNum - 1];
    location2Lat = locationLat[intArrivalNum - 1];
    location2Long = locationLong[intArrivalNum - 1];
    
    cout << "The distance between the two points in miles is " << haversine(location1Lat, location1Long, location2Lat, location2Long, earthRadius) << endl;
    cout << "It should the average plane about " << getFlightTime(location1Lat, location1Long, location2Lat, location2Long) << " hours to travel from " << location1Name << " to " << location2Name << "." << endl;
    
    return 0;
    
    
}


