#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>

using namespace std;

class Employee {
    public:
    void setName(string n);
    void setWage(double w);
    void setPos(string pos);
    void printDetails();
    string getName() const;
    double getWage() const;
    string getPos() const;
    string empDetails() const;
    
    
    private:
    string name;
    double wage;
    string position;
    
};

void Employee::setWage(double w){
    wage = w;
}

void Employee::setName(string n){
    name = n;
}

void Employee::setPos(string pos){
    position = pos;
}

double Employee::getWage() const {
    return wage;
}

string Employee::getName() const{
    return name;
}

string Employee::getPos() const{
    return position;
}





int main(){
    cout << "Hello, this program will allow you to perform various functions, as shown below." << endl;
    
    string empName;
    string empPos;
    string empWage;
    string userInput;
    int intUserInput;
    vector<Employee> employees;
    bool run = true;
    while(run == true){
    cout << "1. Print list of employees." << endl << "2. Calculate total wages." << endl << "3. Add new employee." << endl << "4. Exit application." << endl;
    cout << "Enter the numerated value of the operation you would like to perform." << endl;

    cin >> userInput; 
    intUserInput = atoi(userInput.c_str());
        
    if(intUserInput > 4 || intUserInput < 1){
        cout << "Invalid input! Please enter a numerical value listed." << endl;
    }        
    
    else if (intUserInput == 1){
        for(int i = 0; i < employees.size(); i++){
        cout << employees.at(i).getName() << "   " << employees.at(i).getPos() << "    " << employees.at(i).getWage() << endl;
        }
    }
    
    else if (intUserInput == 2){
        double hourlyWage = 0;
        double hoursWorked = 0;
        for(int i = 0; i < employees.size(); i++){
            cout << "Please input the hours worked by " << employees.at(i).getName() << endl;
            cin >> hoursWorked;
            hourlyWage = employees.at(i).getWage();
            cout << employees.at(i).getName() << "'s hourly wage is " << hourlyWage << endl;
            cout << employees.at(i).getName() << " worked " << hoursWorked << " hours this week" << endl;
            double totalWage = totalWage + hourlyWage * hoursWorked;
            cout << "The total wages for the week for " << employees.at(i).getName() << " are $" << hourlyWage * hoursWorked << endl;
            cout << "The total wages for the week for all employees are $" << totalWage << endl;
            
        }
        if(employees.size() < 1){
            cout << "There are no employees, so the total wages are $0." << endl;
        }
        

    }
    
    else if (intUserInput == 3){
        bool addAnother = true;
        
        while(addAnother == true){
        int addMore = 0;
        cout << "Please enter the employee first name" << endl;
        cin >> empName;
        cout << "Please enter the employee position" << endl;
        cin >> empPos;
        cout << "Please enter the employee wage in dollars" << endl;
        bool isNumerical = false;
        double dobEmpWage = 0;
        while(isNumerical == false){
        cin >> empWage; 
        dobEmpWage = atoi(empWage.c_str());
        if(dobEmpWage == 0){
        cout << "Invalid input! Please enter a numerical value above zero (pay your employees)." << endl;
        } 
        else 
        isNumerical = true;
        }
        Employee e;
        e.setName(empName); e.setWage(dobEmpWage); e.setPos(empPos);
        employees.push_back(e);
        cout <<"Would you like to add another employee?" << endl << "1. Yes" << endl << "2. No" << endl;
        addAnother = false;
        cin >> addMore;
        if(addMore == 1){
            addAnother = true;
        }
        else if (addMore == 2){
            addAnother = false;
        }
        else
            cout << "Please enter a number 1 or 2" << endl;
            
        }
    }
    
    else if (intUserInput == 4){
        cout << "Thank you for using the program! Give me a 100 now." << endl;
        run = false;
    }
        
    }
    return 0;
}